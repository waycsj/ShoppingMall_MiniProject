package org.example.shopping_mall.entity;

public enum OrderStatus {
  ordered, partialCancelled, totalCancelled, delivered, payed, prepared, completed;
}
