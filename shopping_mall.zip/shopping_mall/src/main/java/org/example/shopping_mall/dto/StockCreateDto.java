package org.example.shopping_mall.dto;


import jakarta.persistence.Entity;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.example.shopping_mall.entity.Warehouse;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class StockCreateDto {
  private Warehouse warehouse;
  private int productId;
  private long quantity;
}
