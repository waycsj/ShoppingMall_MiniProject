package org.example.shopping_mall.entity;

public enum DeliveryStatus {
  prepared, delivering, delivered;
}
