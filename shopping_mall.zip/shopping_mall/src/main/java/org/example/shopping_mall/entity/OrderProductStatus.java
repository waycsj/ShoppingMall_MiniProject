package org.example.shopping_mall.entity;

public enum OrderProductStatus {
  ordered,canceled

}
