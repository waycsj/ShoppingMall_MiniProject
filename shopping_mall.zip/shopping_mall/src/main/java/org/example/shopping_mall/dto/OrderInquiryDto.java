package org.example.shopping_mall.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.example.shopping_mall.entity.Order;
import org.example.shopping_mall.entity.OrderStatus;

import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class OrderInquiryDto {
  private long orderId;
  private int memberId;
  private String memberName; //N+1쿼리
  private LocalDateTime orderDate;
  private long totalQuantity;
  private long totalPrice;
  private OrderStatus status;
  private LocalDateTime statusChangeDate;

  public static OrderInquiryDto of (Order order) {
    OrderInquiryDto dto = new OrderInquiryDto();
    dto.setOrderId(order.getOrderId());
    dto.setMemberId(order.getMember().getMemberId());
    dto.setMemberName(order.getMember().getMemberName());
    dto.setOrderDate(order.getOrderDate());
    dto.setTotalPrice(order.getTotalPrice());
    dto.setTotalQuantity(order.getTotalQuantity());
    dto.setStatus(order.getOrderStatus());
    dto.setStatusChangeDate(order.getStatusChangeDate());
    return dto;
  }
}
