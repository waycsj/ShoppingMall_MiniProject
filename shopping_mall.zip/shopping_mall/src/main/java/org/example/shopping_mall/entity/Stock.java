package org.example.shopping_mall.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.example.shopping_mall.exceoption.NoEnoughStockException;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Stock {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private int stockId;
  @Enumerated(EnumType.STRING)
  private Warehouse warehouse;
  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name="product_id")
  private Product product;
  private long quantity;
  //편의 메서드를 이용하여 : 수량 증가(주문 취소시)/ 수량 감소(주문 완료시)
  public void increaseStock(int quantity) {
    this.quantity += quantity;
  }

  public void decreaseStock(int quantity) {
    if(this.quantity < quantity) {
      throw new NoEnoughStockException("재고가 부족합니다.");
    }
    this.quantity -= quantity;
  }
}