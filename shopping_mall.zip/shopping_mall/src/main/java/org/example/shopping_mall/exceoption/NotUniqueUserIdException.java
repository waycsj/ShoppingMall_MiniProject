package org.example.shopping_mall.exceoption;

public class NotUniqueUserIdException extends RuntimeException {
  public NotUniqueUserIdException() {
    super();
  }

  public NotUniqueUserIdException(String message) {
    super(message);
  }
}
