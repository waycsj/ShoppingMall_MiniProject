package org.example.shopping_mall.exceoption;

public class NotUniqueProductNameException extends RuntimeException {
 public NotUniqueProductNameException() {
   super();
 }
  public NotUniqueProductNameException(String message) {
    super(message);
  }
}
