package org.example.shopping_mall.exceoption;

public class NotUniqueStockException extends RuntimeException {
  public NotUniqueStockException() {
    super();
  }

  public NotUniqueStockException(String message) {
    super(message);
  }
}
