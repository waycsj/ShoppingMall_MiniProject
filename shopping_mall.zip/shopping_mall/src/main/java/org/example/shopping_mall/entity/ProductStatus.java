package org.example.shopping_mall.entity;

public enum ProductStatus {
  active, inactive, others;//판매가능 판매불가 기타(품절 등)
}
