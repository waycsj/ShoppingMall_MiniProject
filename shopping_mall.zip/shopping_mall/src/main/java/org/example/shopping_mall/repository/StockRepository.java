package org.example.shopping_mall.repository;

import org.example.shopping_mall.entity.Product;
import org.example.shopping_mall.entity.Stock;
import org.example.shopping_mall.entity.Warehouse;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface StockRepository extends JpaRepository<Stock, Integer> {
  Optional<Stock> findByWarehouseAndProduct(Warehouse warehouse, Product product);
}
