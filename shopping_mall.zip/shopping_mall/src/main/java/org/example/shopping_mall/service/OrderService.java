package org.example.shopping_mall.service;

import lombok.RequiredArgsConstructor;
import org.example.shopping_mall.dto.OrderCreateDto;
import org.example.shopping_mall.dto.OrderInquiryDto;
import org.example.shopping_mall.dto.OrderProductCreateDto;
import org.example.shopping_mall.entity.*;
import org.example.shopping_mall.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
@RequiredArgsConstructor
public class OrderService {
  private final OrderRepository orderRepository;
  private final OrderProductRepository orderProductRepository;
  private final ProductRepository productRepository;
  private final StockRepository stockRepository;
  private final DeliveryRepository deliveryRepository;
  private final MemberRepository memberRepository;

  public OrderInquiryDto createOrder(OrderCreateDto orderDto,
                                     OrderProductCreateDto... orderProductDtos) {
    Member member = memberRepository.findById(orderDto.getMemberId()).get();
    List<OrderProduct> orderProducts = new ArrayList<>();

    for (OrderProductCreateDto orderProductDto : orderProductDtos) {
      Product product = productRepository.findById(orderProductDto.getProductId()).get();
      Stock stock = stockRepository.findByWarehouseAndProduct(Warehouse.KR, product).get();
      OrderProduct orderProduct = OrderProduct.createOrderProduct(
          product, orderProductDto.getQuantity(), product.getPrice(), stock
      );
      orderProducts.add(orderProduct);
    }

    Delivery delivery = new Delivery(
        0L, null, orderDto.getAddress(), DeliveryStatus.prepared, LocalDateTime.now()
    );

    Order order = Order.createOrder(
        member, delivery, orderProducts);
    delivery.setOrder(order);
    Order save = orderRepository.save(order);
    return OrderInquiryDto.of(save);
  }
}
