package org.example.shopping_mall.service;

import lombok.RequiredArgsConstructor;
import org.example.shopping_mall.dto.StockCreateDto;
import org.example.shopping_mall.entity.Product;
import org.example.shopping_mall.entity.Stock;
import org.example.shopping_mall.entity.Warehouse;
import org.example.shopping_mall.exceoption.NotUniqueStockException;
import org.example.shopping_mall.repository.ProductRepository;
import org.example.shopping_mall.repository.StockRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Service
@RequiredArgsConstructor
@Transactional
public class StockService {
  private final StockRepository stockRepository;
  private final ProductRepository productRepository;

  public int addStock(StockCreateDto stockDto) {
    Product product = productRepository.findById(stockDto.getProductId()).get();
    if(checkUniqueStock(Warehouse.KR, product)){
      Stock stock = new Stock(
          0, Warehouse.KR,
          product, stockDto.getQuantity()
      );
      Stock save = stockRepository.save(stock);
      return save.getStockId();
    }
    return 0;
  }

  boolean checkUniqueStock(Warehouse warehouse, Product product) {
    Optional<Stock> byStock = stockRepository.findByWarehouseAndProduct(warehouse, product);
    if (byStock.isPresent()) {
      throw new NotUniqueStockException("이미 재고자료가 존재합니다.");
    }
    return true;
  }

}
