package org.example.shopping_mall.exceoption;

public class OrderCancelException extends RuntimeException {
  public OrderCancelException() {
    super();
  }

  public OrderCancelException(String message) {
    super(message);
  }
}
