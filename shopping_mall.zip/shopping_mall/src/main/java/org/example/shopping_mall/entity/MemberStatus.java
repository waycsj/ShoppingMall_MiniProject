package org.example.shopping_mall.entity;

public enum MemberStatus {
  A, B; //A: 가입회원, B: 탈퇴회원
}
