package org.example.shopping_mall.exceoption;

public class NoEnoughStockException extends RuntimeException {

  public NoEnoughStockException() {
    super();
  }

  public NoEnoughStockException(String message) {
    super(message);
  }
}
