package org.example.shopping_mall.service;

import jakarta.transaction.Transactional;
import org.example.shopping_mall.dto.product.ProductCreateDto;
import org.example.shopping_mall.dto.product.ProductInquiryDto;
import org.example.shopping_mall.dto.StockCreateDto;
import org.example.shopping_mall.entity.Warehouse;
import org.example.shopping_mall.exceoption.NotUniqueStockException;
import org.example.shopping_mall.repository.StockRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.assertThrows;

@SpringBootTest
@Transactional
public class StockServiceTest {

  @Autowired
  private StockService stockService;

  @Autowired
  private StockRepository stockRepository;

  @Autowired
  private ProductService productService;

  @Test
  void 상품재고등록테스트() {
    ProductCreateDto product = new ProductCreateDto(
        "test1", 100, 210
    );
    ProductInquiryDto newProduct = productService.addProduct(product);
    StockCreateDto stockDto = new StockCreateDto(
        Warehouse.KR, newProduct.getProductId(), 100
    );
    stockService.addStock(stockDto);

    StockCreateDto stockDto1 = new StockCreateDto(
        Warehouse.KR, newProduct.getProductId(), 100
    );

    assertThrows(NotUniqueStockException.class, ()-> stockService.addStock(stockDto));



  }
}
