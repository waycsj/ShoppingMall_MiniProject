package org.example.shopping_mall.service;

import org.assertj.core.api.Assertions;
import org.example.shopping_mall.dto.OrderCreateDto;
import org.example.shopping_mall.dto.OrderProductCreateDto;
import org.example.shopping_mall.dto.StockCreateDto;
import org.example.shopping_mall.dto.member.MemberCreateDto;
import org.example.shopping_mall.dto.member.MemberInquiryDto;
import org.example.shopping_mall.dto.product.ProductCreateDto;
import org.example.shopping_mall.dto.product.ProductInquiryDto;
import org.example.shopping_mall.entity.Member;
import org.example.shopping_mall.entity.OrderProduct;
import org.example.shopping_mall.entity.Warehouse;
import org.example.shopping_mall.repository.MemberRepository;
import org.example.shopping_mall.repository.OrderProductRepository;
import org.example.shopping_mall.repository.OrderRepository;
import org.example.shopping_mall.repository.ProductRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Commit;
import org.springframework.transaction.annotation.Transactional;

@SpringBootTest
@Transactional
@Commit
class OrderServiceTest {

  @Autowired
  private OrderService orderService;
  @Autowired
  private OrderRepository orderRepository;
  @Autowired
  private OrderProductRepository orderProductRepository;

  @Autowired
  private ProductRepository productRepository;
  @Autowired
  private MemberService memberService;
  @Autowired
  private StockService stockService;
  @Autowired
  private ProductService productService;

  @Test
  void 주문생성테스트() {
    MemberCreateDto memberCreateDto = new MemberCreateDto(
        "test1", "aaa", "1111", "a", "1", "a"
    );
    MemberInquiryDto memberDto = memberService.addMember(memberCreateDto);
    ProductCreateDto productDto = new ProductCreateDto(
        "test1", 100, 120
    );
    ProductInquiryDto newProduct = productService.addProduct(productDto);
    StockCreateDto stockDto = new StockCreateDto(
        Warehouse.KR, newProduct.getProductId(), 10000
    );
    stockService.addStock(stockDto);// when (주문을 생성했음)
    OrderCreateDto orderCreateDto = new OrderCreateDto(memberDto.getMemberId(), "test-address");
    OrderProductCreateDto orderProductDto = new OrderProductCreateDto(newProduct.getProductId(), 200);
    orderService.createOrder(orderCreateDto, orderProductDto);
    // then (잘 만들어졌음)
    Assertions.assertThat(orderRepository.findAll()).hasSize(1);
    Assertions.assertThat(orderProductRepository.findAll()).hasSize(1);
  }
}