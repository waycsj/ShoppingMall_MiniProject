package org.example.shopping_mall.entity;

import static org.junit.jupiter.api.Assertions.*;

class StockTest {

}